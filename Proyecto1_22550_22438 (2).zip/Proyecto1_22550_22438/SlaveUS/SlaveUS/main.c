/*
 * main.c
 *
 * Created: 3/1/2025 6:53:55 PM
 *  Author: bjosu
 */ 



#define F_CPU 16000000

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include "I2C/I2C.h"

#define SlaveAddress 0x40


uint8_t buffer = 0;
uint8_t lecturaUS = 0;  //Almacena el valor de la lectura del sensor ultr�s�nico
uint8_t valorUS = 0;    //Almacena la lectura ya operada para mostar la distancia en un display.

volatile uint16_t pulse = 0;   //Almacena el pulso enviado por el sensor
volatile uint8_t distance = 0xFF; //Se convierte la se�al de pulso a un valor para mostrar en cm
/* valorUS = lecturaUS/58; for centimeter
   valorUS = lecturaUS/148; for inches
*/  
 

//-------- Prototipos de funci�n ------------------------------ 
void initUS(void);           //Se inicializa los pines, el Timer1 y la interrupci�n de Pin Change.
void US_Request (void);      // Inicia la comunicaci�n con el sensor ultras�nico
uint8_t US_Receive (void);   //Esta funci�n ya no se utiliza.


int main(void)
{
	
	DDRB |= (1<<DDB5);
	PORTB &= ~(1<<PORTB5);
	
	I2C_Slave_Init(SlaveAddress);
	initUS();
	
	sei(); //Habilita las interrupciones
	
    while(1)
    {
		//Se inicia calibraci�n del sensor
		US_Request();
		//Delay para calibraci�n.
		_delay_ms(100);
		
		
		
		if(buffer == 'R'){
			//Se enciende LED indicador de comunicaci�n. 
			PINB |= (1<<PINB5);
			buffer = 0;}
		
    }
}



//-------- Funciones ------------------------------ 
void initUS(void){
	DDRC |= (1 << DDC0);  // Configurar PC0 como salida; Trigger pin
	PORTC &= ~(1 << PORTC0); //Asegurar se�al en bajo antes de iniciar comunicaci�n
	//DDRC &= ~(1<<PINC1); // Configurar PC1 como entrada; Echo pin 
	PORTC |= (1 << PINC1); // Pull-up en ECHO_PIN

	
	// Configuraci�n Pin Change para PC1 (Echo del US)
	PCICR |= (1 << PCIE1);   // Habilita PCINT1 (PORTC)
	PCMSK1 |= (1 << PCINT9); // Habilita PCINT9 (PC1)
	
	TCCR1B |= (1 << CS11); // Prescaler 8
	TCNT1 = 0; // Inicia en 0
	TCCR1A |= (1 << COM1A1) | (1 << WGM11);
	TCCR1B |= (1 << WGM13) | (1 << WGM12);
	ICR1 = 20000; // 20 ms (50 Hz)

}

void US_Request(void){
	PORTC |= (1 << PINC0);  // Enviar se�al alta
	_delay_us(10);  // Mantener se�al baja al menos 10us
	PORTC &= ~(1 << PINC0);  // Bajar la se�al
	
	
}

uint8_t US_Receive(void){
	US_Request();
	
	uint8_t data = 0; 
	
	//Esperar a que ECHO se ponga en alto
	while (!(PINC & (1 << PINC1)));
	
	// Contar el tiempo que ECHO permanece en alto
	uint16_t count = 0;
	while (PINC & (1 << PINC1)) {
		_delay_us(10);
		count++;
		if (count >= 4000) return 400; // Si se pasa el tiempo, devolver distancia m�xima (~2m)
	}

	return count;
}


//---Interrupciones------------------------------------------------------------------------------------------
ISR(TWI_vect){
	uint8_t estado;
	estado = TWSR & 0xFC;
	switch(estado){
		case 0x60:
		case 0x70:
		TWCR |= (1<< TWINT);
		break;
		case 0x80:
		case 0x90:
		buffer = TWDR;
		TWCR |= (1<< TWINT); // Se limpia la bandera
		break;
		case 0xA8:
		case 0xB8:
		TWDR = distance; // Cargar el dato
		TWCR = (1 << TWEN)|(1 << TWIE)|(1 << TWINT)|(1 << TWEA); // Inicia el envio
		break;
		default: // Se libera el bus de cualquier error
		TWCR |= (1<< TWINT)|(1<<TWSTO);
		break;
	}
}

ISR(PCINT1_vect) {
	static uint8_t last_state = 0;
	uint8_t current_state = (PINC & (1 << PINC1)) ? 1 : 0;
	
	if (current_state != last_state) {
		if (current_state == 1) { // Flanco ascendente (inicio del pulso)
			TCNT1 = 0; // Reinicia el timer
			} else { // Flanco descendente (fin del pulso)
			pulse = TCNT1; // Captura el ancho del pulso
			// C�lculo correcto: (pulse_width * 0.5 �s) / 58 �s/cm
			distance = (pulse * 0.5) / 58;
			if (distance > 200 || pulse == 0) {
				distance = 0xFF; // Distancia fuera de rango o error
			}
		}
		last_state = current_state;
	}
}
