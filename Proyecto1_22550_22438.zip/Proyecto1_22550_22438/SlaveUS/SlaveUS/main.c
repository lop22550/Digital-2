/*
 * main.c
 *
 * Created: 3/1/2025 6:53:55 PM
 *  Author: bjosu
 */ 



#define F_CPU 16000000

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include "I2C/I2C.h"

#define SlaveAddress 0x40


uint8_t buffer = 0;
uint8_t lecturaUS = 0;  //Almacena el valor de la lectura del sensor ultr�s�nico
uint8_t valorUS = 0;    //Almacena la lectura ya operada para mostar la distancia en un display.

/* valorUS = lecturaUS/58; for centimeter
   valorUS = lecturaUS/148; for inches
*/  
 

//-------- Prototipos de funci�n ------------------------------ 
void US_Request (void);
uint8_t US_Receive (void);


int main(void)
{
	DDRB |= (1<<DDB5);
	PORTB &= ~(1<<PORTB5);
	
	I2C_Slave_Init(SlaveAddress);
	
	sei(); //Habilita las interrupciones
	
    while(1)
    {
		lecturaUS = US_Receive();
		_delay_ms(500);
		
		// Iniciando conversi�n del sensor ultras�nico
		valorUS = lecturaUS/6 ;
		
		if(buffer == 'R'){
			PINB |= (1<<PINB5);
			buffer = 0;}
		
    }
}



//-------- Funciones ------------------------------ 

void US_Request(void){
	DDRC |= (1 << DDC0);  // Configurar PC0 como salida
	PORTC &= ~(1 << PORTC0); //Asegurar se�al en bajo antes de iniciar comunicaci�n
	_delay_us(2);
	PORTC |= (1 << PORTC0);  // Enviar se�al alta
	_delay_us(11);  // Mantener se�al baja al menos 10us
	PORTC &= ~(1 << PORTC0);  // Bajar la se�al
}

uint8_t US_Receive(void){
	DDRC &= ~(1<<PINC1);
	US_Request();
	
	uint8_t data = 0; 
	
	//Esperar a que ECHO se ponga en alto
	while (!(PINC & (1 << PINC1)));
	
	// Contar el tiempo que ECHO permanece en alto
	uint16_t count = 0;
	while (PINC & (1 << PINC1)) {
		_delay_us(10);
		count++;
		if (count >= 4000) return 400; // Si se pasa el tiempo, devolver distancia m�xima (~2m)
	}

	return count;
}


//---Interrupciones------------------------------------------------------------------------------------------
ISR(TWI_vect){
	uint8_t estado;
	estado = TWSR & 0xFC;
	switch(estado){
		case 0x60:
		case 0x70:
		TWCR |= (1<< TWINT);
		break;
		case 0x80:
		case 0x90:
		buffer = TWDR;
		TWCR |= (1<< TWINT); // Se limpia la bandera
		break;
		case 0xA8:
		case 0xB8:
		TWDR = valorUS; // Cargar el dato
		TWCR = (1 << TWEN)|(1 << TWIE)|(1 << TWINT)|(1 << TWEA); // Inicia el envio
		break;
		default: // Se libera el bus de cualquier error
		TWCR |= (1<< TWINT)|(1<<TWSTO);
		break;
	}
}
