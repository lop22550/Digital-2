/*
 * Universidad del Valle de Guatemala 
 * Boris Josu� L�pez Moreira
 * Carn� 22550
 * Electr�nica digital 2 
 * Secci�n 11
 * Created: 2/6/2025 4:37:03 PM
 */ 

#include <avr/io.h>
#include <util/delay.h> 
#include <avr/interrupt.h>
#include "ADC/ADC.h"
//#include "UART9600/UART9600.h"
#include "SPI/SPI.h"

//#define F_CPU 16000000UL

uint8_t valorSPI = 0;
uint8_t valor_adc = 0; 

void refreshPORT(uint8_t valor);

int main(void)
{ 
	cli();
	
	//Programaci�n para MAESTRO
	/*DDRC |= (1<<DDC0)|(1<<DDC1)|(1<<DDC2)|(1<<DDC3)|(1<<DDC4)|(1<<DDC5);
	DDRD |= (1<<DDD2)|(1<<DDD3);
	DDRB |= (1<<PORTB2);
	PORTB |= (1<<PORTB2);
	PORTC &= ~((1<<PORTC0)|(1<<PORTC1)|(1<<PORTC2)|(1<<PORTC3)|(1<<PORTC4)|(1<<PORTC5));
	PORTD &= ~((1<<PORTD2)|(1<<PORTD3));*/
	sei();
	initADC();
	DDRD |= ((1<<DDD2)|(1<<DDD3)|(1<<DDD4)|(1<<DDD5));
	PORTD = 0;	
	//spiInit(SPI_MASTER_OSC_DIV16, SPI_DATA_ORDER_MSB, SPI_CLOCK_IDLE_LOW, SPI_CLOCK_FIRST_EDGE);
	ADCSRA |= (1<<ADSC);

    while(1)
    {
		/*PORTB &= ~(1<<PORTB2);  //SLAVE SELECT
		
		spiWrite('c');
		valorSPI = spiRead();
		refreshPORT(valorSPI);
       
	   PORTB |= (1<<PORTB2);    //SLAVE SELECT
	   
	   _delay_ms(250);*/
	_delay_ms(10);	
	PORTD = valor_adc<<2;

    }
	
	//Programaci�n para ESCLAVO
	/*DDRC |= (1<<DDC1)|(1<<DDC2)|(1<<DDC3)|(1<<DDC4)|(1<<DDC5);
	DDRD |= (1<<DDD2)|(1<<DDD3)|(1<<DDD4);
	PORTC &= ~((1<<PORTC1)|(1<<PORTC2)|(1<<PORTC3)|(1<<PORTC4)|(1<<PORTC5));
	PORTD &= ~((1<<PORTD2)|(1<<PORTD3)|(1<<PORTD4));
	
	spiInit(SPI_SLAVE_SS,SPI_DATA_ORDER_MSB, SPI_CLOCK_IDLE_LOW, SPI_CLOCK_FIRST_EDGE);
	initADC();
	SPCR */
	
}

void refreshPORT(uint8_t valor){
	if(valor & 0b10000000){
		PORTD |= (1<<PORTD3);
	}else {
		PORTD &= ~(1<<PORTD3);
	}
	
	if(valor & 0b01000000){
		PORTD |= (1<<PORTD2);
		}else {
		PORTD &= ~(1<<PORTD2);
	}
	
	if(valor & 0b00100000){
		PORTC |= (1<<PORTC5);
		}else {
		PORTC &= ~(1<<PORTC5);
	}
	
	if(valor & 0b00010000){
		PORTC |= (1<<PORTC4);
		}else {
		PORTC &= ~(1<<PORTC4);
	}
	
	if(valor & 0b00010000){
		PORTC |= (1<<PORTC4);
		}else {
		PORTC &= ~(1<<PORTC4);
	}
	
	if(valor & 0b00001000){
		PORTC |= (1<<PORTC3);
		}else {
		PORTC &= ~(1<<PORTC3);
	}
	
	if(valor & 0b00000100){
		PORTC |= (1<<PORTC2);
		}else {
		PORTC &= ~(1<<PORTC2);
	}
	
	if(valor & 0b00000010){
		PORTC |= (1<<PORTC1);
		}else {
		PORTC &= ~(1<<PORTC1);
	}
	
	if(valor & 0b00000001){
		PORTC |= (1<<PORTC0);
		}else {
		PORTC &= ~(1<<PORTC0);
	}
}
	
	

ISR (ADC_vect){
	
	valor_adc = ADCH; 

	ADCSRA |= (1<<ADIF);
	ADCSRA |= (1<<ADSC);  //Inici conversi�n;
}